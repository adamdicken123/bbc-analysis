# BBC Analysis

This analysis uses source data which is not published here.

This repository only contains the analysis and some of the data in an aggregated form.

If you wish to run the notebook in its entirity then please copy the 7 files names like 000{i}_part_00 to the `/data` folder first.

The notebook can be viewed here however in a complete state using the GitHub nbviewer.